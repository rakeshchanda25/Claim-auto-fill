# Plain-English → Medical Claim PDF Filler

A working end-to-end pipeline: give it a plain-English description of a
medical claim, it fills the empty `Editable-Member-Claim-form.pdf` and
gives you back a filled PDF.

## How to run it

```bash
pip install pypdf pdfplumber --break-system-packages   # if not already installed

python run.py "My name is Ramesh Kumar, male, 34 years old. I am the self
insured. My policy number is HLT-88213. I am admitted to Apollo Hospital
on 12-Jan-2026 for a fracture from a road accident and discharged on
18-Jan-2026, in a single occupancy room. My address is 221 MG Road, city
Bangalore, state Karnataka, pin code 560001. Email me at
ramesh@example.com, phone 9876543210. My PAN is ABCDE1234F, account
number 12345678901 with HDFC Bank, IFSC HDFC0001234. Signed at Bangalore."
```

Or from a file:
```bash
python run.py --file my_claim_notes.txt
```

Output (in `output/`):
- `filled_claim_form.pdf` — the filled PDF
- `parsed_data.json` — what was extracted from your text (for transparency/debugging)
- `field_values.json` — the exact field_id → value pairs written into the PDF

## Architecture

```
plain English text
      │
      ▼
scripts/parse_input.py   — regex/keyword extractor → {logical_key: value}
      │
      ▼
scripts/field_map.py     — logical_key → actual PDF field_id (verified against this template)
      │
      ▼
scripts/fill_form.py     — builds field_values.json, calls the pdf skill's
      │                     fill_fillable_fields.py to write the PDF
      ▼
output/filled_claim_form.pdf
```

This mirrors the general architecture discussed earlier (Ingestor → Schema
→ Intent Parser → Mapper → Writer), specialized for this one PDF. To port
it to a *different* form, you'd only need to regenerate `field_map.py`
(the field IDs are template-specific) — `parse_input.py` and `fill_form.py`
stay the same in concept.

## What's covered

The parser + field map currently handle the fields that map cleanly onto a
free-text claim narrative:
- Primary insured: name, policy no, TPA ID, certificate no, address, city/state/pin, phone, email
- Patient: name, gender, age, relationship to insured, occupation, address
- Hospitalization: hospital name, room type, cause (injury/illness/maternity), admission & discharge dates, diagnosis, system of medicine
- Bank details: PAN, account number, IFSC, bank name, cheque-payable-to
- Declaration: place

## Known limitations (please read before you assume something's broken)

1. **Source PDF field/box misalignment.** This particular PDF's fillable
   fields are positioned slightly below their printed comb-boxes (verified
   by testing two independent PDF-writing approaches with identical
   results) — this is a defect in the original template file, not the
   pipeline. The *data* lands in the *correct* field every time (check
   `field_values.json`), but visually the text sits a bit low/overlapping
   the row beneath. To get pixel-perfect placement, the PDF skill's
   `FORMS.md` "Non-fillable fields" annotation approach (manual coordinate
   placement) can be used as a fallback — it's more work per field but
   guarantees exact positioning regardless of the AcroForm's own rects.
2. **Itemized bill amounts (Section E/F) aren't auto-filled.** This form
   has ~100+ tiny "Rs" amount boxes whose field IDs (`Rs`, `Rs_2`, `Rs_3`...)
   aren't self-describing and weren't individually verified — see
   `scripts/field_map.py` docstring for how to extend the map if you need
   them (use `scripts/imgs/page_1.png` + `field_info.json` rects to confirm
   each one visually before mapping).
3. **The parser is rule-based (regex), not an LLM.** It's fully offline and
   fast, but will miss phrasings it wasn't written for. `parse_input.py` is
   intentionally isolated so you can swap in an LLM-based extractor later
   without touching the rest of the pipeline — just keep the same output
   shape (`{logical_key: value}` dict using the keys in `field_map.py`).
4. **Patient's own Date of Birth has no fillable field in this PDF.** The
   printed DOB boxes in Section C exist visually but aren't wired up as
   AcroForm fields in the source file (confirmed — there's a gap between
   `undefined_13` and `undefined_16` where it should be).

## File structure

```
claimfill/
├── run.py                  # entry point
├── input/template.pdf      # the empty claim form
├── scripts/
│   ├── parse_input.py      # plain English → structured data
│   ├── field_map.py        # structured data key → PDF field_id
│   ├── fill_form.py        # writes the PDF
│   └── field_info.json     # full raw field list (321 fields) for reference
└── output/                 # generated on each run
```
