"""
field_map.py

Maps human-meaningful claim data keys to the actual field_ids inside
Editable-Member-Claim-form.pdf (verified against field_info.json + visual
inspection of the rendered pages).

Each entry is: logical_key -> {"field_id": ..., "page": ..., "type": "text"|"mark"|"checkbox",
                                "on_value": <only for checkbox type>}

"mark" = a text-type field that represents a checkbox drawn as boxed letters
         (e.g. Male / Female). We fill it with "X" to mark it.
"checkbox" = a true AcroForm checkbox. We fill it with its checked_value (e.g. "/On").

NOTE: This form has ~320 fields total. This map covers the fields that are
realistically extractable from a plain-English claim narrative (the member's
personal/hospital/claim identity details). Fine-grained itemised bill amounts
(Section E/F, 100+ small "Rs" boxes) are NOT auto-mapped because the field
IDs for those are not reliably distinguishable from field_id text alone —
see README "Known limitations" for how to extend this map if you need them.
"""

FIELD_MAP = {
    # ---------- Section A: Primary Insured ----------
    "policy_no":            {"field_id": "a Policy No", "page": 1, "type": "text"},
    "certificate_no":       {"field_id": "b Sl No Certificate no", "page": 1, "type": "text"},
    "tpa_id":                {"field_id": "c Company TPA ID No", "page": 1, "type": "text"},
    "insured_name":          {"field_id": "Text2", "page": 1, "type": "text"},
    "insured_address_l1":    {"field_id": "e Address", "page": 1, "type": "text"},
    "insured_address_l2":    {"field_id": "undefined_5", "page": 1, "type": "text"},
    "insured_address_l3":    {"field_id": "undefined_6", "page": 1, "type": "text"},
    "insured_address_l4":    {"field_id": "undefined_7", "page": 1, "type": "text"},
    "insured_city":          {"field_id": "City", "page": 1, "type": "text"},
    "insured_state":         {"field_id": "State", "page": 1, "type": "text"},
    "insured_pincode":       {"field_id": "Pin Code", "page": 1, "type": "text"},
    "insured_phone":         {"field_id": "Phone No", "page": 1, "type": "text"},
    "insured_email":         {"field_id": "Email ID", "page": 1, "type": "text"},

    # ---------- Section C: Patient (insured person hospitalized) ----------
    "patient_name":          {"field_id": "Text3", "page": 1, "type": "text"},
    "patient_gender_male":   {"field_id": "Male", "page": 1, "type": "mark"},
    "patient_gender_female": {"field_id": "Female", "page": 1, "type": "mark"},
    "patient_age_years":     {"field_id": "Text4", "page": 1, "type": "text"},
    "patient_age_months":    {"field_id": "Text5", "page": 1, "type": "text"},
    "relationship_self":     {"field_id": "Self", "page": 1, "type": "mark"},
    "relationship_spouse":   {"field_id": "Spouse", "page": 1, "type": "mark"},
    "relationship_child":    {"field_id": "Child", "page": 1, "type": "mark"},
    "relationship_father":   {"field_id": "Father", "page": 1, "type": "mark"},
    "relationship_mother":   {"field_id": "Mother", "page": 1, "type": "mark"},
    "occupation_service":    {"field_id": "Service", "page": 1, "type": "mark"},
    "occupation_self_employed": {"field_id": "Self Employed", "page": 1, "type": "mark"},
    "occupation_homemaker":  {"field_id": "Home Maker", "page": 1, "type": "mark"},
    "occupation_student":    {"field_id": "Student", "page": 1, "type": "mark"},
    "occupation_retired":    {"field_id": "Retired", "page": 1, "type": "mark"},
    "patient_address_l1":    {"field_id": "g Address if diffrent from above", "page": 1, "type": "text"},
    "patient_city":          {"field_id": "City_2", "page": 1, "type": "text"},
    "patient_state":         {"field_id": "State_2", "page": 1, "type": "text"},
    "patient_pincode":       {"field_id": "Pin Code_2", "page": 1, "type": "text"},
    "patient_phone":         {"field_id": "Phone No_2", "page": 1, "type": "text"},
    "patient_email":         {"field_id": "Email ID_2", "page": 1, "type": "text"},

    # ---------- Section D: Hospitalization ----------
    "hospital_name":         {"field_id": "a Name of Hospital where Admited", "page": 1, "type": "text"},
    "room_daycare":          {"field_id": "Day care", "page": 1, "type": "checkbox", "on_value": "/On"},
    "room_single":           {"field_id": "Single occupancy", "page": 1, "type": "checkbox", "on_value": "/On"},
    "room_3plus":            {"field_id": "3 or more beds per room", "page": 1, "type": "checkbox", "on_value": "/On"},
    "cause_injury":          {"field_id": "Injury", "page": 1, "type": "checkbox", "on_value": "/On"},
    "cause_illness":         {"field_id": "Illness", "page": 1, "type": "checkbox", "on_value": "/On"},
    "cause_maternity":       {"field_id": "Maternity", "page": 1, "type": "checkbox", "on_value": "/On"},
    "date_injury_or_delivery": {"field_id": "Text7", "page": 1, "type": "text"},
    "date_admission":        {"field_id": "Text6", "page": 1, "type": "text"},
    "time_admission":        {"field_id": "Text9", "page": 1, "type": "text"},
    "date_discharge":        {"field_id": "Text8", "page": 1, "type": "text"},
    "time_discharge":        {"field_id": "Text10", "page": 1, "type": "text"},
    "system_of_medicine":    {"field_id": "j System of Medicine", "page": 1, "type": "text"},
    "diagnosis":             {"field_id": "Diagnosis", "page": 1, "type": "text"},

    # ---------- Section G: Bank details ----------
    "pan":                   {"field_id": "a PAN", "page": 1, "type": "text"},
    "account_number":        {"field_id": "b Account Number", "page": 1, "type": "text"},
    "bank_name_branch":      {"field_id": "c Bank Name and Branch", "page": 1, "type": "text"},
    "cheque_payable_to":     {"field_id": "d Cheque  DD Payable details", "page": 1, "type": "text"},
    "ifsc_code":             {"field_id": "e IFSC Code", "page": 1, "type": "text"},

    # ---------- Page 2: Declaration ----------
    "declaration_place":     {"field_id": "Place", "page": 2, "type": "text"},
}
