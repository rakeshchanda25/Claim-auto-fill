"""
parse_input.py

Turns a plain-English claim description into a structured dict of
logical_key -> value, using the same logical_keys defined in field_map.py.

This is a rule-based (regex/keyword) extractor -- no external API calls,
so it runs fully offline. It is intentionally conservative: if it can't
confidently find a value, it leaves that key out rather than guessing.

For production use, this module is the natural place to swap in an LLM-based
extractor (e.g. call Claude with a structured-output prompt) for far more
robust understanding of free-form narratives -- the rest of the pipeline
(field_map.py, fill_form.py) does not need to change.
"""

import re


def _search(pattern, text, group=1, flags=re.IGNORECASE):
    m = re.search(pattern, text, flags)
    return m.group(group).strip() if m else None


def _mark_if_present(text, *keywords):
    low = text.lower()
    return any(kw in low for kw in keywords)


def parse_claim_text(text: str) -> dict:
    data = {}

    # ---- Names ----
    name = _search(r"(?:my|patient|member|insured)(?:'s)? name is\s*([A-Za-z .]+?)(?:[,.\n]|$)", text)
    if name:
        data["patient_name"] = name.title()
        data["insured_name"] = name.title()

    # If insured/policyholder explicitly different from patient
    insured_name = _search(r"policyholder(?:'s)? name(?: is|:)?\s*([A-Za-z .]+?)(?:[,.\n]|$)", text)
    if insured_name:
        data["insured_name"] = insured_name.title()

    # ---- Policy / TPA / Certificate ----
    # "is/as/:" separator is optional and variable, so strip a leading " is " / " as " / ":" explicitly
    _lbl = r"\s*(?:is|as|:)?\s*"
    policy_no = _search(r"policy\s*(?:no\.?|number)" + _lbl + r"([A-Za-z0-9\-/]+)", text)
    if policy_no:
        data["policy_no"] = policy_no

    tpa_id = _search(r"tpa\s*id\s*(?:no\.?)?" + _lbl + r"([A-Za-z0-9\-/]+)", text)
    if tpa_id:
        data["tpa_id"] = tpa_id

    cert_no = _search(r"certificate\s*(?:no\.?|number)" + _lbl + r"([A-Za-z0-9\-/]+)", text)
    if cert_no:
        data["certificate_no"] = cert_no

    # ---- Gender ----
    if re.search(r"\bmale\b", text, re.IGNORECASE) and not re.search(r"\bfemale\b", text, re.IGNORECASE):
        data["patient_gender_male"] = "X"
    elif re.search(r"\bfemale\b", text, re.IGNORECASE):
        data["patient_gender_female"] = "X"

    # ---- Age ----
    age_years = _search(r"(\d{1,3})\s*(?:years?|yrs?)(?:\s*old)?", text)
    if age_years:
        data["patient_age_years"] = age_years
    age_months = _search(r"(\d{1,2})\s*months?\b(?!\s*old)", text)
    if age_months and "year" in text.lower():
        data["patient_age_months"] = age_months

    # ---- Relationship to primary insured ----
    rel_map = {
        "relationship_self": ["self", "myself", "i am the insured"],
        "relationship_spouse": ["spouse", "wife", "husband"],
        "relationship_child": ["son", "daughter", "child"],
        "relationship_father": ["father"],
        "relationship_mother": ["mother"],
    }
    for key, kws in rel_map.items():
        if _mark_if_present(text, *kws):
            data[key] = "X"
            break

    # ---- Occupation ----
    occ_map = {
        "occupation_service": ["employed", "service", "working", "job"],
        "occupation_self_employed": ["self-employed", "self employed", "business owner", "freelance"],
        "occupation_homemaker": ["homemaker", "housewife"],
        "occupation_student": ["student"],
        "occupation_retired": ["retired"],
    }
    for key, kws in occ_map.items():
        if _mark_if_present(text, *kws):
            data[key] = "X"
            break

    # ---- Contact ----
    email = _search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text, group=0)
    if email:
        data["insured_email"] = email
        data["patient_email"] = email

    phone = _search(r"(?:phone|mobile|contact)(?:\s*no\.?)?\s*[:\-]?\s*(\+?\d[\d\- ]{7,14}\d)", text)
    if phone:
        data["insured_phone"] = phone
        data["patient_phone"] = phone

    pincode = _search(r"pin\s*code\s*[:\-]?\s*(\d{6})", text) or _search(r"\b(\d{6})\b(?=\s*(?:pin|pincode)?)", text)
    if pincode:
        data["insured_pincode"] = pincode

    city = _search(r"(?:city|based in|residing in|living in)\s*[:\-]?\s*([A-Za-z ]+?)(?:[,.\n]|$)", text)
    if city:
        data["insured_city"] = city.strip().title()

    state = _search(r"state\s*[:\-]?\s*([A-Za-z ]+?)(?:[,.\n]|$)", text)
    if state:
        data["insured_state"] = state.strip().title()

    address = _search(r"address\s*(?:is|:)?\s*([^.\n]+)", text)
    if address:
        data["insured_address_l1"] = address.strip()

    # ---- Hospital / hospitalization ----
    hosp = _search(r"(?:admitted (?:to|at)|hospital(?:ised|ized)? at|at) ([A-Za-z0-9 .&'-]+?(?:hospital|clinic|medical center|nursing home))", text, flags=re.IGNORECASE)
    if hosp:
        data["hospital_name"] = hosp.strip().title()

    if _mark_if_present(text, "day care", "daycare"):
        data["room_daycare"] = True
    elif _mark_if_present(text, "single room", "single occupancy", "private room"):
        data["room_single"] = True
    elif _mark_if_present(text, "shared room", "3 or more", "general ward"):
        data["room_3plus"] = True

    if _mark_if_present(text, "accident", "injury", "injured", "fracture"):
        data["cause_injury"] = True
    elif _mark_if_present(text, "pregnan", "delivery", "maternity", "childbirth"):
        data["cause_maternity"] = True
    elif _mark_if_present(text, "illness", "fever", "surgery", "disease", "infection"):
        data["cause_illness"] = True

    # Dates: admitted [to X hospital] on DATE, discharged [from X] on DATE
    # (accepts many common date formats; tolerates words like "to Apollo Hospital" in between)
    date_pat = r"(\d{1,2}[/-][A-Za-z0-9]{1,9}[/-]\d{2,4}|\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+\s+\d{4})"
    admit = _search(r"admitted\b[^.\n]{0,60}?\bon\s*" + date_pat, text, flags=re.IGNORECASE)
    if admit:
        data["date_admission"] = admit
    discharge = _search(r"discharged\b[^.\n]{0,60}?\bon\s*" + date_pat, text, flags=re.IGNORECASE)
    if discharge:
        data["date_discharge"] = discharge

    diagnosis = _search(r"diagnos(?:is|ed with)\s*[:\-]?\s*([^.\n]+)", text)
    if diagnosis:
        data["diagnosis"] = diagnosis.strip()

    # ---- Bank details ----
    pan = _search(r"\bpan\b" + _lbl + r"([A-Z]{5}\d{4}[A-Z])", text, flags=re.IGNORECASE)
    if pan:
        data["pan"] = pan.upper()

    acc = _search(r"account\s*(?:no\.?|number)" + _lbl + r"(\d{6,20})", text)
    if acc:
        data["account_number"] = acc

    ifsc = _search(r"ifsc\s*(?:code)?" + _lbl + r"([A-Z]{4}0[A-Z0-9]{6})", text, flags=re.IGNORECASE)
    if ifsc:
        data["ifsc_code"] = ifsc.upper()

    # "with HDFC Bank" or "bank name is HDFC Bank" -- name is the 1-4 word phrase right before "Bank"
    bank = _search(r"(?:^|[,.\s])((?:[A-Za-z&'-]+\s){0,3}Bank)\b", text)
    if bank:
        words = [w for w in bank.strip().split() if w.lower() not in ("with", "is", "as", "the", "a")]
        data["bank_name_branch"] = " ".join(words).title()

    place = _search(r"(?:signed at|place\s*[:\-])\s*([A-Za-z ]+?)(?:[,.\n]|$)", text)
    if place:
        data["declaration_place"] = place.strip().title()

    return data


if __name__ == "__main__":
    import sys, json
    text = sys.argv[1] if len(sys.argv) > 1 else sys.stdin.read()
    print(json.dumps(parse_claim_text(text), indent=2))
