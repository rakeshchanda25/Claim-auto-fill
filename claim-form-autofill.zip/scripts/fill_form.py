"""
fill_form.py

Takes parsed claim data (dict of logical_key -> value) and the field_map,
produces field_values.json (the format expected by the pdf skill's
fill_fillable_fields.py), then invokes that script to produce the final
filled PDF.
"""

import json
import subprocess
import sys
from pathlib import Path

from field_map import FIELD_MAP

PDF_SKILL_SCRIPTS = Path("/mnt/skills/public/pdf/scripts")


def build_field_values(data: dict) -> list:
    values = []
    for logical_key, value in data.items():
        if logical_key not in FIELD_MAP:
            continue  # unmapped key, skip silently
        spec = FIELD_MAP[logical_key]

        if spec["type"] == "checkbox":
            if not value:
                continue
            entry_value = spec["on_value"]
        elif spec["type"] == "mark":
            entry_value = "X"
        else:  # plain text
            entry_value = str(value)

        values.append({
            "field_id": spec["field_id"],
            "description": logical_key,
            "page": spec["page"],
            "value": entry_value,
        })
    return values


def fill_pdf(input_pdf: str, data: dict, output_pdf: str, work_dir: str = "."):
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)

    field_values = build_field_values(data)
    fv_path = work / "field_values.json"
    fv_path.write_text(json.dumps(field_values, indent=2))

    result = subprocess.run(
        [sys.executable, str(PDF_SKILL_SCRIPTS / "fill_fillable_fields.py"),
         input_pdf, str(fv_path), output_pdf],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr, file=sys.stderr)
        raise RuntimeError("PDF fill step failed -- see output above")

    return output_pdf, field_values


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("input_pdf")
    p.add_argument("data_json", help="JSON file with logical_key: value pairs")
    p.add_argument("output_pdf")
    args = p.parse_args()

    data = json.loads(Path(args.data_json).read_text())
    fill_pdf(args.input_pdf, data, args.output_pdf)
    print(f"Wrote {args.output_pdf}")
