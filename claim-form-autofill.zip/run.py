#!/usr/bin/env python3
"""
run.py -- end-to-end demo: plain English claim narrative -> filled claim PDF.

Usage:
    python run.py "My name is Ramesh Kumar, male, 34 years old. I was admitted
    to Apollo Hospital on 12-Jan-2026 for a fracture and discharged on
    18-Jan-2026 in a single occupancy room. My policy number is HLT-88213.
    My PAN is ABCDE1234F, account number 12345678901 with HDFC Bank,
    IFSC HDFC0001234. Email me at ramesh@example.com, phone 9876543210."

    # or read from a file:
    python run.py --file my_claim_notes.txt

Output:
    output/filled_claim_form.pdf
    output/parsed_data.json   (what was extracted, for transparency)
    output/field_values.json  (exact field_id -> value written to the PDF)
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "scripts"))

from parse_input import parse_claim_text
from fill_form import fill_pdf

BASE = Path(__file__).parent
TEMPLATE_PDF = BASE / "input" / "template.pdf"
OUTPUT_DIR = BASE / "output"


def main():
    ap = argparse.ArgumentParser(description="Fill the medical claim PDF from plain English.")
    ap.add_argument("text", nargs="?", help="Plain English claim description")
    ap.add_argument("--file", help="Read claim description from a text file instead")
    ap.add_argument("--template", default=str(TEMPLATE_PDF), help="Path to the empty claim PDF")
    ap.add_argument("--out", default=str(OUTPUT_DIR / "filled_claim_form.pdf"))
    args = ap.parse_args()

    if args.file:
        text = Path(args.file).read_text()
    elif args.text:
        text = args.text
    else:
        ap.error("Provide claim text as an argument or via --file")

    OUTPUT_DIR.mkdir(exist_ok=True)

    print("Step 1/3: Parsing plain-English claim text ...")
    data = parse_claim_text(text)
    (OUTPUT_DIR / "parsed_data.json").write_text(json.dumps(data, indent=2))
    print(json.dumps(data, indent=2))

    if not data:
        print("\nWarning: nothing could be extracted from the text. "
              "Try being more explicit (e.g. 'policy number is ...', "
              "'admitted to X hospital on DATE').")

    print("\nStep 2/3: Mapping fields and filling the PDF ...")
    output_pdf, field_values = fill_pdf(args.template, data, args.out, work_dir=str(OUTPUT_DIR))
    (OUTPUT_DIR / "field_values.json").write_text(json.dumps(field_values, indent=2))

    print(f"\nStep 3/3: Done. Filled PDF written to: {output_pdf}")
    print(f"Fields filled: {len(field_values)}")


if __name__ == "__main__":
    main()
